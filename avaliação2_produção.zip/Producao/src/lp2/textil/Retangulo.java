package lp2.textil;

import java.util.ArrayList;

public class Retangulo extends Figura {

	private double base;
	private double altura;
	private String material;
	
	private ArrayList<Figura> figuras;

	public Retangulo(String material, double base, double altura) {
		figuras= new ArrayList<Figura>();
		this.setBase(base);
		this.setAltura(altura);
		this.material = material;
	}

	public void adicionar(Figura figura, double x, double y) throws Exception {
		if (isInside(figura, x, y)) {
			this.figuras.add(figura);
			figura.setX(x);
			figura.setY(y);
		}
		else {
			throw new Exception("Fora da Forma");
		}
	}
	
	/**
	 * Retorna a area dispon�vel em metros quadrados
	 * @return area dispon�vel
	 */
	public double getAreaDisponivelMetrosQuadrados() {
		double areaUtilizada = 0;
		for(Figura figura : figuras) {
			areaUtilizada += figura.getArea();
		}
		
		return this.getArea() - areaUtilizada;
	}
	
	public double getAreaDisponivelPercentual() {
		return (this.getAreaDisponivelMetrosQuadrados() * 100) / this.getArea();
	}
	
	private boolean isInside(Figura figura, double x, double y) {
		double alturaForma = this.getAltura();
		double larguraForma = this.getBase();
		
		if (x >= 0.0 &&  x <= larguraForma 
				&& y >= 0.0 &&  y  <= alturaForma) {
			double comprimento;
			
			if (figura instanceof Circulo) {
				comprimento = ((Circulo) figura).getRaio() * 2;
			} else {
				comprimento = ((Quadrado) figura).getLado();
			}

			double posicaoY = y + comprimento;
			double posicaoX = x + comprimento;

			// se nao passar do limite do retangulo
			if (posicaoY <= alturaForma && posicaoX <= larguraForma) {
				return true;
			}
		}
		
		return false;
	}

	public double getBase() {
		return base;
	}

	public void setBase(double base) {
		this.base = base;
		this.updateArea();
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
		this.updateArea();
	}
	
	public String getMaterial() {
		return material;
	}

	public void updateArea() {
		this.area = this.getBase() * this.getAltura();
	}

	@Override
	public String toString() {
		String msg;
		msg = super.toString() + " material " + this.getMaterial() +
				" base  " + this.getBase() +
				" altura: " + this.getAltura();
		return msg;
	}

}
