package lp2.textil;

import javax.swing.JOptionPane;

public class Industria {

	public static void main(String[] args) throws Exception {
		
		// cria o material
		String material = JOptionPane.showInputDialog("Informe o material: ");
		double largura = Double.parseDouble( JOptionPane.showInputDialog("Informe a largura: ") );
		double altura = Double.parseDouble( JOptionPane.showInputDialog("Informe a altura: ") );
		
		Retangulo forma = new Retangulo(material, largura, altura);
		
		boolean continuarAdicionando = true;
		
		do {
			String tipo = JOptionPane.showInputDialog("Informe o tipo de recorte:\n" +
													  "1- Quadrado\n2- Circulo ");

			Figura figura = null;
			switch(tipo) {
				case "1":
					double lado = Double.parseDouble( JOptionPane.showInputDialog("Quadrado\nInforme o tamanho do lado: ") );
					figura = new Quadrado(lado);
					break;
					
				case "2":
					double raio = Double.parseDouble( JOptionPane.showInputDialog("Circulo\nInforme o tamanho do raio: ") );
					figura = new Circulo(raio);
					break;
			}
			
			double x = Double.parseDouble( JOptionPane.showInputDialog("Informe a posi��o X: ") );
			double y = Double.parseDouble( JOptionPane.showInputDialog("Informe a posi��o Y: ") );
			
			try {
				forma.adicionar(figura, x, y);
			} catch( Exception e) {
				JOptionPane.showMessageDialog(null, "Espa�o indispon�vel.");
			}
			
			String mensagem = "Espa�o dispon�vel em metros quadrados: " + forma.getAreaDisponivelMetrosQuadrados() +
					   "\nEspa�o dispon�vel em percentual: " + forma.getAreaDisponivelPercentual();
			JOptionPane.showMessageDialog(null, mensagem);
			
			String opcao = JOptionPane.showInputDialog("Deseja adicionar outra figura?(S/N)").toUpperCase();
			continuarAdicionando = opcao.equals("S") ? true : false;
		
		} while(continuarAdicionando);
	}
}
