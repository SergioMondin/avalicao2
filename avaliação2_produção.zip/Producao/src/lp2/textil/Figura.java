package lp2.textil;

/*
 * @autor smondwork@gamail.com
 */
public abstract class Figura {

	protected double area;
	protected double perimetro;
	protected double x;
	protected double y;

	public Figura() {
		this.area=0.0;
		this.perimetro=0.0;
	}

	public abstract void updateArea();
	
	public double getArea() {
		return area;
	}

	public double getPerimetro() {
		return perimetro;
	}

	public void setPerimetro(double perimetro) {
		this.perimetro = perimetro;
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}
	
	@Override	
	public String toString(){
		String msg="";
		msg= "area: " + area + " Perimetro: " + perimetro;
		return msg;
	}

}
