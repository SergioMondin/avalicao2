package lp2.textil;

public class Circulo extends Figura {

	private double raio;

	public Circulo(double raio) {
		this.setRaio(raio);

	}

	public double getRaio() {
		return raio;
	}

	public void setRaio(double raio) {
		this.raio = raio;
		this.updateArea();
		this.perimetro = 2 * Math.PI;
	}
	
	public void updateArea() {
		this.area = Math.PI * Math.pow(this.raio, 2);
	}

	@Override
	public String toString() {
		String msg;
		msg = super.toString() + " raio:  " + this.raio;
		return msg;
	}
}
