package lp2.textil;

public class Quadrado extends Figura {

	private double lado;

	public Quadrado(double lado) {
		this.setLado(lado);

	}

	public double getLado() {
		return lado;
	}

	public void setLado(double lado) {
		this.lado = lado;
		this.updateArea();
		this.perimetro = 4 * this.lado;
	}
	
	public void updateArea() {
		this.area = Math.pow(this.lado, 2);
	}

	@Override
	public String toString() {
		String msg;
		msg = super.toString()+"lado:  "+ this.lado ;
		return msg;
	}

}
